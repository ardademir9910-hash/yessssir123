<?php
if ($_POST) {
    $db_host = $_POST['db_host'];
    $db_user = $_POST['db_user'];
    $db_pass = $_POST['db_pass'];
    $db_name = $_POST['db_name'];

    // Test connection
    $conn = new mysqli($db_host, $db_user, $db_pass);
    if ($conn->connect_error) {
        $error = "Bağlantı hatası: " . $conn->connect_error;
    } else {
        // Create DB if not exists
        $sql = "CREATE DATABASE IF NOT EXISTS `$db_name` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
        if ($conn->query($sql) === TRUE) {
            $conn->select_db($db_name);
            
            // Import SQL
            $sql_file = 'sxware_clean.sql';
            if (file_exists($sql_file)) {
                $query = file_get_contents($sql_file);
                // Split SQL file into queries
                $queries = explode(';', $query);
                
                foreach ($queries as $q) {
                    $q = trim($q);
                    if (!empty($q)) {
                         try {
                            $conn->query($q);
                         } catch (Exception $e) {
                             // Ignore errors for now or log them
                         }
                    }
                }
                
                // Write config file
                $config_content = "<?php\n";
                $config_content .= "// htdocs/inc/backend/db_conn.php\n\n";
                $config_content .= "\$db_host = '" . addslashes($db_host) . "';\n";
                $config_content .= "\$db_user = '" . addslashes($db_user) . "';\n";
                $config_content .= "\$db_pass = '" . addslashes($db_pass) . "';\n";
                $config_content .= "\$db_name = '" . addslashes($db_name) . "';\n\n";
                $config_content .= "\$conn = new mysqli(\$db_host, \$db_user, \$db_pass, \$db_name);\n\n";
                $config_content .= "if (\$conn->connect_error) {\n";
                $config_content .= "    die(\"Connection failed: \" . \$conn->connect_error);\n";
                $config_content .= "}\n\n";
                $config_content .= "\$conn->set_charset(\"utf8mb4\");\n";
                $config_content .= "?>";
                
                file_put_contents('htdocs/inc/backend/db_conn.php', $config_content);
                
                $success = "Kurulum başarıyla tamamlandı! Lütfen install.php ve sxware_clean.sql dosyalarını siliniz.";
            } else {
                $error = "SQL dosyası bulunamadı!";
            }
        } else {
            $error = "Veritabanı oluşturulurken hata: " . $conn->error;
        }
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sistem Kurulumu</title>
    <style>
        body { font-family: sans-serif; padding: 50px; }
        .container { max-width: 500px; margin: 0 auto; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input { width: 100%; padding: 8px; }
        button { padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer; }
        .alert { padding: 15px; margin-bottom: 20px; border: 1px solid transparent; border-radius: 4px; }
        .alert-danger { color: #721c24; background-color: #f8d7da; border-color: #f5c6cb; }
        .alert-success { color: #155724; background-color: #d4edda; border-color: #c3e6cb; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Sistem Kurulumu</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php else: ?>
        <form method="post">
            <div class="form-group">
                <label>Veritabanı Sunucusu (Host)</label>
                <input type="text" name="db_host" value="localhost" required>
            </div>
            <div class="form-group">
                <label>Veritabanı Kullanıcısı</label>
                <input type="text" name="db_user" value="root" required>
            </div>
            <div class="form-group">
                <label>Veritabanı Şifresi</label>
                <input type="password" name="db_pass">
            </div>
            <div class="form-group">
                <label>Veritabanı Adı</label>
                <input type="text" name="db_name" value="sxware" required>
            </div>
            <button type="submit">Kurulumu Başlat</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
