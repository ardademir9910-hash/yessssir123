<?php
/**
 * footer_start.php
 *
 * Author: pixelcave
 *
 * All vital JS scripts are included here
 *
 */
?>
<style>
	body{background-color: #202632}
</style>
<script src="<?php echo $one->assets_folder; ?>/js/oneui.app.min.js"></script>
