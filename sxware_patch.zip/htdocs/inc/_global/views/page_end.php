<?php
/**
 * page_end.php
 *
 * Author: pixelcave
 *
 * The end section of each page used in every page of the template
 *
 */
?>
  </main>
  <!-- END Main Container -->
  <?php if(isset($one->inc_footer) && $one->inc_footer) { include($one->inc_footer); } ?>
</div>
<!-- END Page Container -->
