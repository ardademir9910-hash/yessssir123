<?php
error_reporting(0); 

header("Content-Type: application/json; utf-8;");
 
$iban = addslashes($_GET['iban']);

$data = "iban=$iban&x=51&y=10";

$url = "https://hesapno.com/cozumle_iban";

$ladexs = curl_init();
curl_setopt($ladexs, CURLOPT_URL, $url);
curl_setopt($ladexs, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ladexs, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ladexs, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ladexs, CURLOPT_POSTFIELDS, $data);

$response = curl_exec($ladexs);

$dom = new DOMDocument();
$dom->loadHTML($response);

$xpath = new DOMXPath($dom);
$div_element = $xpath->query("//div[@id='iban']")->item(0);

if ($div_element) {
    $bank_name = "";
    $apibilg="";
    $bank_kod = "";
    $swift = "";
    $hesap_no = "";
    $sube_ad = "";
    $sube_kod = "";
    $il = "";
    $ilce = "";
    $tel = "";
    $fax = "";
    $adres = "";
    

    $elements = $xpath->query(".//div[@style='margin-left:12px; margin-top:12px; margin-bottom:12px']/b", $div_element);
    foreach ($elements as $element) {
        $key = trim($element->nodeValue);
        $value = trim($element->nextSibling->nodeValue);

        switch ($key) {
            
  
            case "Ad:":
                if ($bank_name === "") {
                    $bank_name = $value;
                } else {
                    $sube_ad = $value;
                }
                break;
            case "Kod:":
                if ($bank_kod === "") {
                    $bank_kod = $value;
                } else {
                    $sube_kod = $value;
                }
                break;
            case "Swift:":
                $swift = $value;
                break;
            case "Hesap No:":
                $hesap_no = $value;
                break;
            case "İl:":
                $il = $value;
                break;
            case "İlçe:":
                $ilce = $value;
                break;
            case "Tel:":
                $tel = $value;
                break;
            case "Fax:":
                $fax = $value;
                break;
            case "Adres:":
                $adres = $value;
                break;
                case "Telegram:":
                    $tag = $value;
                    break;
        }
    }
   
    $banka_bilgileri = array(
        
        "Adı" => $bank_name,
        "Kod" => $bank_kod,
        "Swift" => $swift,
        "Hesap No" => $hesap_no
    );

    $sube_bilgileri = array(
        "Ad" => $sube_ad,
        "Kod" => $sube_kod,
        "İl" => $il,
        "İlçe" => $ilce,
        "Tel" => $tel,
        "Fax" => $fax,
        "Adres" => $adres,
        
       
    );
  
        

    $json_data = array(
        "BANKA" => $banka_bilgileri,
        "ŞUBE" => $sube_bilgileri
    );


    $json_output = json_encode($json_data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
    echo $json_output;
} else {
$result = array(
        "success" => false,
"message" => "Aranan Ibana Ait Veri Bulunamamıştır"
        );
$json = json_encode($result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
        echo $json;
}
?>