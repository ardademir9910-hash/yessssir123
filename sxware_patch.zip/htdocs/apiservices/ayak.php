<?php


$anubishatali = '"00000000"';

$tc = htmlspecialchars($_GET['tc']);



$ayakhataver = '[{"status":"Başarısız!", "Proxydurum":"TC Boş Bırakılamaz}]';



if ($tc == "") {
    die($ayakhataver);
}



$fayujayakno = rand(33,42);
sleep(6);


echo '[{ "Tc":'. $tc . ',"Ayakno":'. $fayujayakno .'}]';

?>

