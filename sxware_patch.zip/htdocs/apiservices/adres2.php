<?php
header('Content-Type: application/json');
error_reporting(0);


$tc = $_GET['tc'];

$token = "2692461cd188da8e74ab7ea9427637da64ee2ef377de9e1542fe5452d9ba70354d1e3dcec2610338d77a40d94f8d21ea79c5b25f654df3ca610d964bb9729a4f";

$xquens = curl_init();
curl_setopt($xquens, CURLOPT_URL, "https://intvrg.gib.gov.tr/intvrg_server/dispatch");
curl_setopt($xquens, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($xquens, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($xquens, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($xquens, CURLOPT_POST, 1);
curl_setopt($xquens, CURLOPT_POSTFIELDS, "cmd=EBynYetkiIslemleri_vknGirisi&callid=b7e49f9252263-24&token=$token&jp=%7B%22mukellefVergiNo%22%3A%22%22%2C%22mukellefTCKimlikNo%22%3A%22$tc%22%2C%22arac%C4%B1l%C4%B1kSozlesmeTipi%22%3A%220%22%7D");
curl_setopt($xquens, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");
curl_setopt($xquens, CURLOPT_HTTPHEADER, [
    "Referer: https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$token",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Content-Type: application/x-www-form-urlencoded; charset=UTF-8"
]);

$response = curl_exec($xquens);
curl_close($xquens);

$response = "[" . $response . "]";

$data = json_decode($response, true);

foreach ($data as $row) {
    echo "TC Kimlik No: " . $row['data']['mukellef_tckimlikno'] ;
    echo "Doğum Tarihi: " . $row['data']['mukellef_dogum_tarihi'] ;
    echo "Ad: " . $row['data']['mukellef_ad'] ;
    echo "Doğum Yeri: " . $row['data']['mukellef_dogum_yeri'] ;
    echo "Vergi No: " . $row['data']['mukellef_vergino'] ;
    echo "Adres: " . $row['data']['mukellef_adres'] ;
    echo "Vergi Dairesi Adı: " . $row['data']['mukellef_vdkodu']['vergidaireleri'][0]['vdadi'] ;
    echo "Vergi Dairesi Kodu: " . $row['data']['mukellef_vdkodu']['vergidaireleri'][0]['vdkodu'] ;
    echo "Şirket Türü: " . $row['data']['mukellef_sirketturu'] ;
    
}
?>
