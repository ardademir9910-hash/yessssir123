<?php

$tc = $_GET['tc'];

$ironclad = "38a96d2f6189cd32c4d28dcb5b8a4413b3b61cbab0b009276588d43eecc37b99e6d6b2a5448f6f75c55b73dcf06d1d26c54f9bb4f7ef945291df3c42e519429a"; 

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://intvrg.gib.gov.tr/intvrg_server/dispatch?cmd=EBynYetkiIslemleri_vknGirisi&callid=15d6d64f555e2-25&token=$ironclad&jp=%7B%22mukellefVergiNo%22%3A%22%22%2C%22mukellefTCKimlikNo%22%3A%22$tc%22%2C%22arac%C4%B1l%C4%B1kSozlesmeTipi%22%3A%220%22%7D");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Accept: application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding: gzip, deflate, br',
    'Accept-Language: en-US,en;q=0.6',
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'Host: intvrg.gib.gov.tr',
    'Origin: https://intvrg.gib.gov.tr',
    'Referer: https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$ironclad',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: same-origin',
    'Sec-GPC: 1',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Brave";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"'
));
$response = curl_exec($ch);
curl_close($ch);
$decodedResponse = gzdecode($response);
if ($decodedResponse === false) {
    echo 'GZIP çözme hatası';
} else {
    $responseData = json_decode($decodedResponse, true);
    if ($responseData === null) {
        echo 'JSON dönüşüm hatası';
    } else {
        header('Content-Type: application/json');
        echo json_encode($responseData);
    }
}
?>
