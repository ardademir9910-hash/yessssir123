<?php
require '../inc/backend/db_conn.php';
header("Content-Type: application/json; charset=utf-8");

$tc = $_GET["tc"];

$stmt = $conn->prepare("SELECT * FROM 116m WHERE TC = ?");
$stmt->bind_param("s", $tc);
$stmt->execute();
$result = $stmt->get_result();

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} 

$stmt2 = $conn->prepare("SELECT * FROM 101m WHERE TC = ?");
$stmt2->bind_param("s", $tc);
$stmt2->execute();
$result2 = $stmt2->get_result();

if ($result2->num_rows > 0) {
    while($row = $result2->fetch_assoc()) {
        $data[] = $row;
    }
}

if (empty($data)) {
    $data = ["message" => "Sonuç bulunamadı"];
}

echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>
