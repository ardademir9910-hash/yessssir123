<?php
require '../inc/backend/db_conn.php';

if (isset($_GET["tc"])) {
    $tc = $_GET["tc"];
    
    // First query to get ANNETC
    $stmt = $conn->prepare("SELECT * FROM `101m` WHERE `TC` = ?");
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $kizliksoyadi = "";
    
    while($row = $result->fetch_assoc()) {
        $annetc = $row["ANNETC"];
        
        // Second query to get ANNETC of ANNETC (Grandmother)
        $stmt2 = $conn->prepare("SELECT * FROM `101m` WHERE `TC` = ?");
        $stmt2->bind_param("s", $annetc);
        $stmt2->execute();
        $resultanasi = $stmt2->get_result();
        
        while($row2 = $resultanasi->fetch_assoc()) {
            $anneannetc = $row2["ANNETC"];
             // Third query to get Grandmother details
             $stmt3 = $conn->prepare("SELECT * FROM `101m` WHERE `TC` = ?");
             $stmt3->bind_param("s", $anneannetc);
             $stmt3->execute();
             $resultanasianasi = $stmt3->get_result();
             
             while($row3 = $resultanasianasi->fetch_assoc()) {
                 $kizliksoyadi = $row3['SOYADI'];
             }
        }
    }
   
    $data = [
    "success" => "true",
    'kizliksoyadi' => $kizliksoyadi
    ];

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
?>
