<?php
require '../inc/backend/db_conn.php';
header("Content-Type: application/json; charset=utf-8");

$tc = $_GET["tc"];

$stmt = $conn->prepare("SELECT TC, ADI, SOYADI, DOGUMTARIHI FROM 101m WHERE TC = ?");
$stmt->bind_param("s", $tc);
$stmt->execute();
$result = $stmt->get_result();

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    $data = ["message" => "Sonuç bulunamadı"];
}

echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>
