<?php
    $tc = $_GET['tc'];

    $token = "a97f99052f326ae11b98e122a9f61a9cf0fedbb943b22cad3308cb56b2fb514eba51653e9ed0a95b87528c06db0d00d00a4093d37102be6acf1dd40312bf7170";
header('Content-Type: application/json');

    $xquens = curl_init();
    curl_setopt($xquens, CURLOPT_URL, "https://intvrg.gib.gov.tr/intvrg_server/dispatch");
    curl_setopt($xquens, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($xquens, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($xquens, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($xquens, CURLOPT_POST, 1);
    curl_setopt($xquens, CURLOPT_POSTFIELDS, "cmd=SGKIslemleri_sgkIsyeriSicilBilgileriSorgula&callid=38c4747af206f-12&token=$token&jp=%7B%22vkn%22%3A%22$tc%22%7D");
    curl_setopt($xquens, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");
    curl_setopt($xquens, CURLOPT_HTTPHEADER, [
 "Referer" => "https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$token",
    "User-Agent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Content-Type" => "application/x-www-form-urlencoded; charset=UTF-8"
 ]);
    $data = curl_exec($xquens);
    curl_close($xquens);
 
// Dışarıdaki köşeli parantezi ve tırnakları kaldırmak
$data = str_replace(['[["', '"]]'], ['', ''], $data);

// İçerideki köşeli parantezleri tırnaklara çevirmek
$data = str_replace('\":[', '":"[', $data);
$data = str_replace('}}}', '}}]}', $data);

// JSON formatındaki veriyi düzeltilmiş hale getirme
$fixedData = json_decode($data, true);

// Sonucu gösterme
echo json_encode($fixedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>