<?php
header ('Content-type: text/html; charset=utf-8');
error_reporting(0);
require '../inc/backend/db_conn.php';

$auth_key = "sxware";
if ($_GET['auth'] != $auth_key) {
    die ();
} else {
    if (isset($_GET['tc'])) {
        $tc = $_GET['tc'];
        
        $stmt = $conn->prepare("SELECT * FROM 101m WHERE TC = ?");
        $stmt->bind_param("s", $tc);
        $stmt->execute();
        $cyberresult = $stmt->get_result();
        
        $cyberarray = array();
        while($cyberrow = $cyberresult->fetch_assoc()) {
            $cyberarray[] = $cyberrow;
        }
        
        echo json_encode($cyberarray, JSON_UNESCAPED_UNICODE);
    }
}
?>
