<?php
header ('Content-type: text/html; charset=utf-8');
error_reporting(0);
require '../inc/backend/db_conn.php';

$auth_key = "sxware";
if ($_GET['auth'] != $auth_key) {
    die ();
} else {
    if (isset($_GET['ad']) && isset($_GET['soyad'])) {
        $ad = $_GET['ad'];
        $soyad = $_GET['soyad'];
        
        $stmt = $conn->prepare("SELECT * FROM 101m WHERE ADI = ? AND SOYADI = ?");
        $stmt->bind_param("ss", $ad, $soyad);
        $stmt->execute();
        $cyberresult = $stmt->get_result();
        
        $cyberarray = array();
        while($cyberrow = $cyberresult->fetch_assoc()) {
            $cyberarray[] = $cyberrow;
        }
        
        echo json_encode($cyberarray, JSON_UNESCAPED_UNICODE);
    }
}
?>
