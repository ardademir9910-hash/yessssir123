﻿<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>agah#3000</title>
<meta name="description" content="agah#3000">
<meta name="author" content="agah#3000">
<meta name="robots" content="noindex, nofollow">
<meta property="og:title" content="agah#3000">
<meta property="og:site_name" content="agah#3000">
<meta property="og:description" content="agah#3000">
<meta property="og:type" content="website">
<meta property="og:url" content="">
<meta property="og:image" content="">
<link rel="shortcut icon" href="assets/media/photo/a_agah_lg.png">
<link rel="icon" type="image/png" sizes="192x192" href="assets/media/photo/a_agah_lg.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/media/photo/a_agah_lg.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" id="css-main" href="assets/css/oneui.min.css">
<link rel="stylesheet" id="css-theme" href="assets/css/themes/modern.min.css">
</head>
<body>
﻿<script>localStorage.setItem('oneuiDarkMode', true);</script>
<div data-action="dark_mode_toggle" id="page-container" class="remember-theme dark-mode">
<div id="page-loader" class="show"></div>
<link rel="shortcur icon" href="../assets/photo">
<main id="main-container">
<div class="hero">
<div class="hero-inner text-center">
<div class="bg-body-extra-light">
<div class="content content-full">
<div class="py-4">

<h2>agah#3000 Hesap Oluşturma</h2>
<p><strong>Boost basarak üyelik almak:</strong> Öncelikle <a href="https://discord.gg/tcCRs4vyDJ" rel="noopener">Discord Sunucumuza</a> 2 Boost basmanız gerekmektedir!</p>
<p>Boost bastıktan sonra boost bastığınıza dair ss alıp ticket kanalına atmanız gerekiyor, bundan önce yapmanız gereken bir şey daha var! <br> <a href="/kayit.jsp" rel="noopener">Agah Kayıt Sayfasına Git!</a> Hesap oluştururken dikkat etmeniz gereken en önemli kural kullanıcı adınızda ( #, @, !, *, - ) Gibi semboller olmamalıdır! <br>Referans Kodu: b5b2d7 <br> <br><strong>BU ADIMIDA TAMAMLADIĞINA GÖRE YAPMAN GEREKEN TEK ŞEY TİCKET AÇILMASINI BEKLEMEK, AÇILDIKTAN SONRA KULLANICI ADINI VE BOOST BASTIĞINA DAİR SS ATMAN! </strong></p>
<p><strong>Günüm azaldı ne yapmalıyım:</strong> <a href="/günümazaldi.jsp" rel="noopener">Gün uzatma sayfasına git</a>.</p>
<a class="link-fx" href="/discord.php">Discorda Katıl</a> yada <a class="link-fx" href="/ticket.php">Ticket Sunucusuna Katıl</a>
</div>
</div>
</div>

</main>

</div>
<style>
	body{background-color: #202632}
</style>
<script src="assets/js/oneui.app.min.js"></script>
<script src="assets/js/plugins/bootstrap-notify/bootstrap-notify.min.js"></script>
<script>One.helpersOnLoad(['jq-notify']);</script>
</body>
</html>

