﻿<?php
header("Content-Type: application/json; Charset-UTF-8");

// Kullanıcıdan TC kimlik numarasını al
$tc = $_GET['tc'];

$token = "dbeeed4c9864508ed55f111beba9f7e83e99c165abf0671dfab336599869e1206ff3e1e38f5c4838baba7e3713dc423315f8d46221744bef389d799d6b788e95";

$url = "https://intvrg.gib.gov.tr/intvrg_server/dispatch?cmd=YMMSozlesmeBlgService_getAdSoyad&callid=822d06348f2af-10&token=$token&jp=%7B%22kayitTCKimlikNo%22%3A%22$tc%22%7D";

$response = file_get_contents($url);

$response = "[" . $response . "]";
$decoded = json_decode($response, true);

$output = array();

foreach ($decoded as $data) {
    $item = array(
        "BU FREE APİ @moskovacheck AİT",
		"TC" => $data['data']['tckimlikno'],
        "Adı" => $data['data']['ad'],
        "Soyadı" => $data['data']['sad'],
        "Anne Adı" => $data['data']['anaadi'],
        "Baba Adı" => $data['data']['babaadi'],
        "Doğum Tarihi" => $data['data']['dogumtarihiformatli'],
        "Doğum Yeri" => $data['data']['dogumyeritext'],
        "Sıra No" => $data['data']['sirano'],
        "Aile Sıra No" => $data['data']['ailesirano'],
        "Cilt No" => $data['data']['ciltno']
    );

    $olumtar = $data['data']['olumtarihi'];
    if (!empty($olumtar)) {
        $formatted_olumtar = substr($olumtar, 0, 4) . '/' . substr($olumtar, 4, 2) . '/' . substr($olumtar, 6);
        $item["Ölüm Tarihi"] = $formatted_olumtar;
    } else {
        $item["Ölüm Tarihi"] = "Belirtilmemiş";
    }

    $output[] = $item;
}

echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
