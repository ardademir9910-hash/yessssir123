<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="a.css">
    
</head>
    


           
                 <!--BAŞLANGIC-->

                 <form action="" method="POST" >
        
                    <div class="block-content tab-content col-sm-12 col-lg-12">
                        <div class="tab-pane active" id="tc" role="tabpanel">
                            <input class="form-control" type="text" id="gsm" name="gsm" placeholder =" GSM Giriniz" maxlength="11"><br><br><br>
                        <center class="">
                        <input type="submit" class="btn waves-effect waves-light btn-rounded btn-success" style="width: 130px; height: 50px; outline: none; margin-left: 5px;" id=re value=" Sorgula">
                        <button onclick=window.print(); id=pı  <input type="submit" class="btn waves-effect waves-light btn-rounded btn-warning" style="width: 130px; height: 50px; outline: none; margin-left: 5px;"><i class="fas fa-search"></i> <b>Yazdır </b> <span  id="sorgulanumber"></span></button>>
                        <button onclick="document.location.reload(true);" id=p <input type="submit" class="btn waves-effect waves-light btn-rounded btn-danger" style="width: 130px; height: 50px; outline: none; margin-left: 5px;"><i class="fas fa-search"></i> <b> Temizle </b><span  id="sorgulanumber"></span></button><br /><br />

                    </center>
                        <div id=e  class="table-responsive">

                            <table id=o class="table table-hover" style="width:100%">
                                <thead id=y>
                                    <tr>
                                        <th>TELEFON NO [GSM NO]</th>
                                        <th>OPERATOR</th>
                                        <th>AUTHOR</th>
                                    </tr>
                                </thead>
                                <tbody id="jojjoojj">
                                <?php
if(isset($_POST['gsm'])) {
  $phone = $_POST['gsm'];
  $opsorgu = substr($phone, 0, 3);
  $telekom = array(501, 505, 506, 507, 551, 552, 553, 554, 555, 559); // TÜRKTELEKOM
  $turkcell = array(530, 531, 532, 533, 534, 535, 536, 537, 538, 539); // TURKCELL
  $vodafone = array(540, 541, 542, 543, 544, 545, 546, 547, 548, 549); // VODAFONE
  $kktc_telsim = array(54285, 54286, 54287, 54288);  // KKTC TELSIM
  $kktc_turkcell = array(53383, 53384, 53385, 53386, 53387);  // KKTC TURKCELL
  $auth="Proxy";

  if (in_array($opsorgu, $telekom)) {
    $operator = "<td>TÜRKTELEKOM<td/>";
  } elseif (in_array($opsorgu, $turkcell)) {
    $operator = "<td>TURKCELL<td/>";
  } elseif (in_array($opsorgu, $vodafone)) {
    $operator = "<td>VODAFONE<td/>";
  } elseif (in_array($opsorgu, $kktc_telsim)) {
    $operator = "<td>KKTC TELSIM<td/>";
  } elseif (in_array($opsorgu, $kktc_turkcell)) {
    $operator = "<td>KKTC TURKCELL<td/>";
  } else {
    $operator = "<td>Bilinmeyen Operatör</td>";
  }

  echo "<td>$phone</td>";
  echo "<td>$operator</td>";
  echo "<td>$auth</td>";
} else {
  echo "<td>Lütfen GSM No Giriniz.</td>";
}
?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


               
            </div>
         </div>
      </div>
      </div>
      </div>
      </div>

    

 <!-- JS
============================================ -->

    <script>
    $("#search").click(function() {

        $.Toast.showToast({
            "title": "Sorgulanıyor...",
            "icon": "loading",
            "duration": 60000
        });
        $.ajax({
            type: 'POST',
            url: 'api/adsoyadpro.php',
            data: {
                'ad': $('#ad').val(),
                'soyad': $('#soyad').val(),
                'il': $('#il').val(),
                'ilce': $('#ilce').val(),
              
            },
            error: function(donen_hata_degeri) {
                return swal({
                    title: "Sistem Hatası",
                    icon: "error"

                });
            },
            success: function(data) {
                $.Toast.hideToast();
                if (data == "empty") {

                    return swal({
                        title: "Aradığınız Kişiye Ait Veri Bulunamadı",
                        icon: "warning"

                    });
                } else if (data == "hata") {

                    return swal({
                        title: "Veri Bulanamadı",
                        icon: "warning"

                    });
                } else if (data == "cooldown") {

                    return swal({
                        title: "Biraz Yavaş AMINA GOYİM",
                        icon: "warning"
                
                });
                } else {
                    $("#sonuc").html(data);
                }


            }
        });
    });
    </script>
    <!-- Global Vendor, plugins & Activation JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!--Plugins JS-->
    <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="assets/js/plugins/tippy4.min.js.js"></script>
    <!--Main JS-->
    <script src="assets/js/main.js"></script>

    <!-- Plugins & Activation JS For Only This Page -->

    <!--Moment-->
    <script src="assets/js/plugins/moment/moment.min.js"></script>

    <!--Daterange Picker-->
    <script src="assets/js/plugins/daterangepicker/daterangepicker.js"></script>
    <script src="assets/js/plugins/daterangepicker/daterangepicker.active.js"></script>

    <!--Echarts-->
    <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
    <script src="assets/js/plugins/chartjs/chartjs.active.js"></script>

    <!--VMap-->
    <script src="assets/js/plugins/vmap/jquery.vmap.min.js"></script>
    <script src="assets/js/plugins/vmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/js/plugins/vmap/maps/samples/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/plugins/vmap/vmap.active.js"></script>
    <script src="assets/js/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="assets/js/plugins/sweetalert/sweetalert.active.js"></script>
    <script src="assets/js/plugins/jquery.toast/jquery.toast.js"></script>
    
    <script src="assets/js/plugins/moment/moment.min.js"></script>
    <script src="assets/js/plugins/inputmask/bootstrap-inputmask.js"></script>

</body>

</html>