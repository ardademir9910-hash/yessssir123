<?php


$baglan = new mysqli('localhost', 'root', '', '101m');

if (isset($_GET["tc"])) {
$tc = $_GET["tc"];
$ty="@PROXYCOMMUN�TY";
$select = $baglan->prepare("SELECT * FROM `101m`");

$sql = "SELECT * FROM `101m` WHERE `TC` = '$tc'";

$result = $baglan->query($sql);
while($row = $result->fetch_assoc()) {
    $sqlanasi = "SELECT * FROM `101m` WHERE `TC` = '" . $row["ANNETC"] ."' ";
    $resultanasi = $baglan->query($sqlanasi);

while($row = $resultanasi->fetch_assoc()) {
    $sqlanasianasi = "SELECT * FROM `101m` WHERE `TC` = '" . $row["ANNETC"] ."' ";
    $resultanasianasi = $baglan->query($sqlanasianasi);
}
while($row = $resultanasianasi->fetch_assoc()) {
    $kizliksoyadi = $row['SOYADI'];
}
}
   
$data = [
"success" => "true",
'kizliksoyadi' => $kizliksoyadi
];

echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);


}

?>
