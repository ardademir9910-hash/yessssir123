<?php  

header("Content-Type: application/json"); 

error_reporting(0);


$plaka = $_GET['plaka'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ccis.cordisnetwork.com/CWC/bridgeDebt");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36");
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "query=plakatabtoplamborc&PlateNumber=$plaka&IsTotalDebtQuery=1&Hash=79974");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding: gzip, deflate, br',
    'Accept-Language: tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'Connection: keep-alive',
	'Cache-Control: max-age=0',
    'Host: ccis.cordisnetwork.com',
    'Referer: https://ccis.cordisnetwork.com/cwc/bridgeDebt?lang=TR',
	'Origin: https://ccis.cordisnetwork.com',
    'sec-ch-ua-mobile: ?0',
	'sec-ch-ua-platform: "Windows"',
	'Sec-Fetch-Dest: document',
	'Sec-Fetch-Mode: navigate',
	'Sec-Fetch-Site: same-origin',
	'Sec-Fetch-User: ?1',
	'Upgrade-Insecure-Requests: 1',
	'sec-ch-ua: "Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
));
$resp = curl_exec($ch);
$resp = preg_replace('/lang="tr"[\s\S]+?td style="height:5px;"/', '', $resp);
$resp = str_replace("</html>", "godomansikeraffetmez", $resp);
$resp = preg_replace('/tbody[\s\S]+?godomansikeraffetmez/', '', $resp);
$resp = str_replace('<html ></td>', "baslasex", $resp);
$resp = preg_replace('/baslasex[\s\S]+?style="height:5px;"/', '', $resp);
$resp = str_replace('></td>
                    </tr>', "baslıyoruz", $resp);
$resp = str_replace('<td style="height:5px;"baslıyoruz
                </', "", $resp);
$resp = str_replace('baslıyoruz', "", $resp);
$resp = str_replace('<!DOCTYPE html>', "", $resp);
$resp = str_replace("<tr class='printtr'>", "", $resp);
$resp = str_replace('<tr>', "", $resp);
$resp = str_replace('</tr>', "", $resp);

$resp = str_replace('> <', ">-<", $resp);
$resp = str_replace('><', ">-<", $resp);
preg_match_all('@<td class="textStyle" >(.*?)</td>@', $resp, $resp);

 
$plaka = $plaka;
$borcturu = $resp[1][0];
$isimsoyisim = $resp[1][7];
$tc = $resp[1][8];
$buro = $resp[1][9];
$burotel = $resp[1][10];
$ceza = $resp[1][5];
$toplamceza = $resp[1][11];

echo json_encode(array("success" => true, "plaka"=> $plaka, "borcTuru"=> $borcturu, "Isimsoyisim" => $isimsoyisim, "Tc" => $tc, "Buro" => $buro, "BuroTelefon" => $burotel, "YazilanCeza" => $ceza, "ToplamCeza" => $toplamceza), JSON_UNESCAPED_UNICODE);