<?php

error_reporting(0);
$tc = $_GET["tc"];

$token = "dbeeed4c9864508ed55f111beba9f7e83e99c165abf0671dfab336599869e1206ff3e1e38f5c4838baba7e3713dc423315f8d46221744bef389d799d6b788e95";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://intvrg.gib.gov.tr/intvrg_server/dispatch");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "cmd=EBynYetkiIslemleri_vknGirisi&callid=95eb685263398-13&token=$token&jp=%7B%22mukellefVergiNo%22%3A%22%22%2C%22mukellefTCKimlikNo%22%3A%22$tc%22%2C%22arac%C4%B1l%C4%B1kSozlesmeTipi%22%3A%220%22%7D");
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Referer: https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$token",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Content-Type: application/x-www-form-urlencoded; charset=UTF-8"
]);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
