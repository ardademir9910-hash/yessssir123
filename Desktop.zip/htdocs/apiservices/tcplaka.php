<?php 
error_reporting(E_ALL); 
header('Content-Type: application/json; charset=utf-8'); 
$tc = filter_input(INPUT_GET, 'tc', FILTER_SANITIZE_FULL_SPECIAL_CHARS); 
if (!$tc) { 
$error_result = array( 
'success' => false, 
'message' => 'Geçersiz kimlik numarası' 
    ); 
echo json_encode($error_result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
exit; 
} 
if (!preg_match('/^\d{11}$/', $tc)) { 
$error_result = array( 
'success' => false, 
'message' => 'Kimlik numarası geçerli bir formatta olmalıdır' 
    ); 
echo json_encode($error_result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
exit; 
} 
if (!is_numeric($tc)) { 
$error_result = array( 
'success' => false, 
'message' => 'Kimlik numarası sadece sayısal değerlerden oluşmalıdır' 
    ); 
echo json_encode($error_result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
exit; 
} 
$allowedIPs = array( 
'127.0.0.1', 
'::1' 
); 
$userIP = $_SERVER['REMOTE_ADDR']; 
if (!in_array($userIP, $allowedIPs)) { 
$error_result = array( 
'success' => false, 
'message' => 'IP Adresiniz Kayıtlı Değil', 
'ip' => $userIP 
    ); 
echo json_encode($error_result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
exit; 
} 
$tc = trim($tc); 
if (isset($_GET['tc'])) { 
$tc = $_GET['tc']; 
$giris_data = [ 
'assoscmd' => 'anologin', 
'rtype' => 'json', 
'userid' => $tc, 
'tc' => $tc, 
'gn' => 'hizliOdeme', 
'tur' => 'gvlgn', 
    ]; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, 'https://ivd.gib.gov.tr/tvd_server/assos-login'); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST'); 
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($giris_data)); 
$response = curl_exec($ch); 
curl_close($ch); 
$token = isset(json_decode($response, true)['token']) ? json_decode($response, true)['token'] : null; 
if ($token) { 
$mevcut_data = [ 
'cmd' => 'aracBilgileriService_aracBilgileriGetir', 
'callid' => 'med', 
'pageName' => 'P_MEVCUT_ARAC_BILGILERI', 
'token' => $token, 
'jp' => '{"sorgulamaTip":"0"}', 
        ]; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, 'https://ivd.gib.gov.tr/tvd_server/dispatch'); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST'); 
curl_setopt($ch, CURLOPT_HTTPHEADER, [ 
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8', 
        ]); 
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($mevcut_data)); 
$response = curl_exec($ch); 
curl_close($ch); 
$mevcutaraclar = isset(json_decode($response, true)['data']['araclar']) ? json_decode($response, true)['data']['araclar'] : null; 
$gecmis_data = [ 
'cmd' => 'aracBilgileriService_aracBilgileriGetir', 
'callid' => 'med', 
'pageName' => 'P_GECMIS_ARAC_BILGILERI', 
'token' => $token, 
'jp' => '{"sorgulamaTip":"0"}', 
        ]; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, 'https://ivd.gib.gov.tr/tvd_server/dispatch'); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST'); 
curl_setopt($ch, CURLOPT_HTTPHEADER, [ 
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8', 
        ]); 
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($gecmis_data)); 
$response = curl_exec($ch); 
curl_close($ch); 
$gecmisaraclar = isset(json_decode($response, true)['data']['araclar']) ? json_decode($response, true)['data']['araclar'] : null; 
if ($mevcutaraclar && $gecmisaraclar) { 
foreach ($gecmisaraclar as $key => $item) { 
if (in_array($item, $mevcutaraclar)) { 
unset($gecmisaraclar[$key]); 
                } 
            } 
        } else { 
$mevcutaraclar = "MevcutAracYok"; 
$gecmisaraclar = "GecmisAracYok"; 
        } 
$cikti = [ 
'response' => [ 
'mevcutAraclar' => $mevcutaraclar, 
'gecmisAraclar' => $gecmisaraclar, 
            ], 
'author' => 't.me/s3nnzy', 
        ]; 
$cikis_data = [ 
'cmd' => 'kullaniciBilgileriService_logout', 
'callid' => 'med', 
'pageName' => 'PG_MAIN_DYNAMIC', 
'token' => $token, 
'jp' => '{}', 
        ]; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, 'https://ivd.gib.gov.tr/tvd_server/dispatch'); 
curl_setopt($ch,
CURLOPT_RETURNTRANSFER, 
true); 
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST'); 
curl_setopt($ch, CURLOPT_HTTPHEADER, [ 
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8', 
        ]); 
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($cikis_data)); 
$response = curl_exec($ch); 
curl_close($ch); 
echo json_encode($cikti, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
    } else { 
echo json_encode(['error' => 'Veri Bulunamadı.'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
    } 
} else { 
echo json_encode(['error' => 'TC PARAMETRESİ EKSİK!'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
} 
?>