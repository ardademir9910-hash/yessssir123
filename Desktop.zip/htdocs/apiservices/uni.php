<?php

header("Content-Type: application/json; charset=utf-8");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "101m";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantı hatası: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["tc"])) {
    $tc = $_GET["tc"];

    $sql = "SELECT TC, ADI, SOYADI, DOGUMTARIHI FROM 101m WHERE TC = '" . $tc . "'";

    $result = $conn->query($sql);

    $response = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data = array(
                
                "TC" => $row["TC"],
                "ADI" => $row["ADI"],
                "SOYADI" => $row["SOYADI"],
                "DOGUMTARIHI" => $row["DOGUMTARIHI"],
                "UNIVERSITE" => getRandomHospital(),
                "BAŞLAMA TARİHİ" => getRandomDate(),
                "YKS SIRALAMASI" => rand(50000,800000),
                "OGRENCI TC" => $tc,
                "REKTOR" => getRandomDoctor()
            );
            $response["data"] = $data;
        }
    }

    header('Content-Type: application/json');
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    header("HTTP/1.1 400 Bad Request");
    echo "Geçersiz istek.";
}

$conn->close();
function getRandomHospital() {
    $hospitals = array(
        "Ankara Hacı Bayram Veli Üniversitesi (AHBVÜ)",
        "Gazi Üniversitesi (GÜ)",
        "Hacettepe Üniversitesi (HÜ)",
        "Ankara Yıldırım Beyazıt Üniversitesi",
        "Akdeniz Üniversitesi ",
        "Bingöl Üniversitesi",
        "Dicle Üniversitesi",
        "İskenderun Teknik Üniversitesi ",
        "Boğaziçi Üniversitesi",
        "Galatasaray Üniversitesi "
    );
    $randomIndex = array_rand($hospitals);
    return $hospitals[$randomIndex];
}

function getRandomDate() {
    $startDate = strtotime("2014-01-01");
    $endDate = strtotime("2022-12-31");
    $randomTimestamp = mt_rand($startDate, $endDate);
    return date("Y/m/d", $randomTimestamp);
}
function getRandomDoctor() {
    $doctors = array(
        "Dr. Ahmet Yılmaz",
        "Dr. Ayşe Kaya",
        "Dr. Mehmet Demir",
        "Dr. Seda Öztürk",
        "Dr. Ali Can",
        "Dr. Fatma Aksoy",
        "Dr. Hasan Yıldız",
        "Dr. Zeynep Şen",
        "Dr. Mustafa Aydın",
        "Dr. Elif Akgün"
    );
    $randomIndex = array_rand($doctors);
    return $doctors[$randomIndex];
}

?>