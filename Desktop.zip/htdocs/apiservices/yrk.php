<?php


$anubishatali = '"00000000"';

$tc = htmlspecialchars($_GET['tc']);



$ayakhataver = '[{"status":"Başarısız!", "ProxyDurum":"TC GİR RAMK!","IhbarNo":'. $anubishatali .',"Author":"Coder By Proxy"}]';



if ($tc == "") {
    die($ayakhataver);
}



$fayujayakno = rand(10,25);
sleep(6);
if ($tc==""){
    echo "SENDE YARRAK YOK KUZ VAR";
    echo ($fayujayakno=='1');
}


echo '[{"Tc":'. $tc . ',"Yarrakuzunlugu":'. $fayujayakno .'}]';

?>

