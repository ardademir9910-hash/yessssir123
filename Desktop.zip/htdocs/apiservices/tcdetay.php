<?php
error_reporting(0);
header("Content-Type: application/json");

$tc = $_GET["tc"];

$url = "https://intvrg.gib.gov.tr/intvrg_server/dispatch";
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$ironclad = "80703690fddbe29f82bec726df5c5b74781663573fff4803d4706f4ed62b31481c8bb4a58edf8e3ee30409f8d664902a6bb5d72517f62d67f1bd9b4f9394248d";

$ironcladdata = "cmd=EBynYetkiIslemleri_vknGirisi&callid=b7e49f9252263-24&token=$ironclad&jp=%7B%22mukellefVergiNo%22%3A%22%22%2C%22mukellefTCKimlikNo%22%3A%22$tc%22%2C%22arac%C4%B1l%C4%B1kSozlesmeTipi%22%3A%220%22%7D";

$header = array(
    'Accept: application/json, text/javascript, */*; q=0.01', 
    'Accept-Language: en-US,en;q=0.9',
    'Connection: keep-alive',
    'Content-Length: 327',
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'Referer: https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$ironclad',
    'Host: intvrg.gib.gov.tr',
    'Origin: https://intvrg.gib.gov.tr',
    'sec-ch-ua: "Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: same-origin',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
curl_setopt($curl, CURLOPT_POSTFIELDS, $ironcladdata);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$sonuc = curl_exec($curl);
curl_close($curl);
$sonuc = "[" . $sonuc . "]";

$son = $sonuc;
$decoded = json_decode($son, true);
foreach ($decoded as $row) 
    $tckn = $row['data']['mukellef_tckimlikno'];
    $ad = $row['data']['mukellef_ad'];
    $dt = $row['data']['mukellef_dogum_tarihi'];
    $dy = $row['data']['mukellef_dogum_yeri'];
    $adres = $row['data']['mukellef_adres'];
    $vergino = $row['data']['mukellef_vergino'];
    $vdadi = $row['data']['mukellef_vdkodu']['vergidaireleri'][0]['vdadi'];
    $vdkodu = $row['data']['mukellef_vdkodu']['vergidaireleri'][0]['vdkodu'];
	
	$ironclad = "$ironclad"; 

$jp = json_encode(array("kayitTCKimlikNo" => "$tc"));
	
    $flash = curl_init();
    curl_setopt($flash, CURLOPT_URL, "https://intvrg.gib.gov.tr/intvrg_server/dispatch");
    curl_setopt($flash, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($flash, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($flash, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($flash, CURLOPT_POST, 1);
    curl_setopt($flash, CURLOPT_POSTFIELDS, "cmd=YMMSozlesmeBlgService_getAdSoyad&callid=ca4d0af947788-14&token=$ironclad&jp=$jp");
    curl_setopt($flash, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");
    curl_setopt($flash, CURLOPT_HTTPHEADER, [
	"Referer" => "https://intvrg.gib.gov.tr/intvrg_side/main.jsp?token=$ironclad",
    "User-Agent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
    "Content-Type" => "application/x-www-form-urlencoded"
	]);
    $response = curl_exec($flash);
    curl_close($flash);
	
	$response = "[" . $response . "]";
	
	$json = json_decode($response, true);
	
    foreach($json as $tasak) {
		$annead = $tasak['data']['aadi'];
		$babaad = $tasak['data']['badi'];
		$annetc = $tasak['data']['annetck'];
		$babatc = $tasak['data']['babatck'];
		$il = $tasak['data']['ilad'];
		$ilce = $tasak['data']['ilcead'];
		$ciltno = $tasak['data']['cno1'];
		$sırano = $tasak['data']['srno'];
		$ailesırano = $tasak['data']['asrno'];
		$ölümtarihi = $tasak['data']['olumtar'];
		$medenihal = $tasak['data']['medenihal'];
		$cinsiyet = $tasak['data']['cns'];
		if ($ölümtarihi != "") {	
		$durumu = "Allah rahmet eylesin ölmüş.";
		}else{
		$durumu = "Yaşıyor";
		}
		if ($cinsiyet != 1) {
		$cinsiyet = "Erkek";
		}else{
		$cinsiyet = "Kadın";	
		}

    // sqlden bilgileri alma başlangıç
    $connect = new mysqli("localhost", "root", "", "116m");
    $sql = "SELECT * FROM 116m WHERE TC='$tc'";
    $result = mysqli_query($connect, $sql) or die("Error in Selecting " . mysqli_error($connect));

    $flash = array();
    while ($hm = mysqli_fetch_assoc($result)) {
        $gsm = $hm["GSM"];
    }

    $connect2 = new mysqli("localhost", "root", "", "101m");

    $sql2 = "SELECT * FROM 101m WHERE TC='$tc'";
    $result = mysqli_query($connect2, $sql2) or die("Error in Selecting " . mysqli_error($connect2));

    $flash2 = array();
    while ($hm2 = mysqli_fetch_assoc($result)) {
        $dogumtarihi = $hm2["DOGUMTARIHI"];
        $annead = $hm2["ANNEADI"];
        $annetc = $hm2["ANNETC"];
        $babaad = $hm2["BABAADI"];
        $babatc = $hm2["BABATC"];
        $il = $hm2["NUFUSIL"];
        $ilce = $hm2["NUFUSILCE"];
    }
    
    $dog = "$dogumtarihi";
    $bugun = date("Y-m-d");
    $diff = date_diff(date_create($dog), date_create($bugun));
    $data = [
        "success" => true,
        "message" => "Bulundu",
        "author" => "@s3nnzy",
        'tc' => $tckn,
        'adsoyad' => $ad,
        'gsm' => $gsm,
        'yaş' => $diff->format('%y YIL %m AY %d GÜN'),
        "dogumtarihi" => $dt,
        "dogumyeri" => $dy,
		'annead' => $annead,
		'annetc' => $annetc,
		'babaad' => $babaad,
		'babatc' => $babatc,
		'ciltno' => $ciltno,
		'ailesırano' => $ailesırano,
		'sırano' => $sırano,
		'ölümtarihi' => $ölümtarihi,
		'durumu' => $durumu,
		'cinsiyet' => $cinsiyet,
		'il' => $il,
		'ilce' => $ilce,
        "adres" => $adres,
        "vergino" => $vergino,
        "vergidadi" => $vdadi,
        "vergidkodu" => $vdkodu
    ];
	

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
?>